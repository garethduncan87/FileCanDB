﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using System.Threading.Tasks;

namespace SharpJsonDBTests
{
    [TestClass]
    public class SharpJsonDBTests
    {
        public SharpJsonDB.StorageMethod ChosenStorage;
        public SharpJsonDBTests()
        {
            this.ChosenStorage = SharpJsonDB.StorageMethod.encrypted;
        }

        [TestMethod]
        public void InsertObjectTest()
        {
            TestObject MyTestObject = new TestObject("insert option test", DateTime.Now, "insert option test " + Guid.NewGuid().ToString("N"), "insert option test");

            SharpJsonDB.SharpJsonDB MySharpJsonDB = new SharpJsonDB.SharpJsonDB(@"c:\sharpjsondb", ChosenStorage);

            string EntryId = MySharpJsonDB.InsertObject(MyTestObject, "Blog", "GarethsBlog");
            if (string.IsNullOrEmpty(EntryId))
            {
                Assert.Fail("No ID returned for newly inserted object");
            }
        }

        [TestMethod]
        public void SelectObjectTest()
        {
            //Craete file first
            SharpJsonDB.SharpJsonDB MySharpJsonDB = new SharpJsonDB.SharpJsonDB(@"c:\sharpjsondb", ChosenStorage);
            TestObject MyTestObject = new TestObject("Select option test", DateTime.Now, "select option test " + Guid.NewGuid().ToString("N"), "select option test" );
            string EntryId = MySharpJsonDB.InsertObject(MyTestObject, "Blog", "GarethsBlog");
            if (string.IsNullOrEmpty(EntryId))
            {
                Assert.Fail("No ID returned for newly inserted object");
            }

            //Select file
            TestObject ReturnedObject;
            ReturnedObject = MySharpJsonDB.DeserializeObject<TestObject>(EntryId, "Blog", "GarethsBlog");
            if (ReturnedObject == null)
            {
                Assert.Fail("No file returned");
            }

            //Delete file as its only a test
            if (!MySharpJsonDB.DeleteObject(EntryId, "Blog", "GarethsBlog"))
            {
                Assert.Fail("Failed to delete file");
            }
        }

        [TestMethod]
        public void DeleteObjectTest()
        {
            SharpJsonDB.SharpJsonDB MySharpJsonDB = new SharpJsonDB.SharpJsonDB(@"c:\sharpjsondb", ChosenStorage);
            //Create file first
            TestObject MyTestObject = new TestObject("delete option test", DateTime.Now, "delete option test " + Guid.NewGuid().ToString("N"), "delete option test");
            string EntryId = MySharpJsonDB.InsertObject(MyTestObject, "Blog", "GarethsBlog");

            if (string.IsNullOrEmpty(EntryId))
            {
                Assert.Fail("No ID returned for newly inserted object");
            }

            if (!MySharpJsonDB.DeleteObject(EntryId, "Blog", "GarethsBlog"))
            {
                Assert.Fail("Failed to delete file");
            }
        }
    }
}
